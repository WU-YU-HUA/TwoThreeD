twothreeD 原創設備模型

glb/：Three.js 等支援 GLB 的工具使用。
dae/：SketchUp 桌面版匯入，每款有一個頂層物件群組。
模型已含純色材質，烘碗機含透明門，沒有外部貼圖。
這些為通用外觀，不是製造尺寸；一般設備依圖框等比配置；兩款支架白板依明確 W/D/H 標示配置。
生成腳本需放回本專案 scripts/ 執行，使用專案附帶的 Three.js。
原創模型 CC0-1.0；來源及生成方式見 SOURCES.txt。
尚未在 SketchUp 實機驗收。
